from setuptools import setup
setup(name="Hkart",
version="0.1",
description="This is ecommerce and blog project created by Hardik Sharma",
Long_description="This is ecommerce and blog project created by Hardik",
author="Hardik Sharma",
packages=['Hkart'],
install_requires=[])